import React from 'react';
import { storiesOf } from '@storybook/react';
import RangeInput from './RangeInput';

storiesOf('Atoms/RangeInput', module).add('Normal', () => <RangeInput />);
