import React from 'react';
import { storiesOf } from '@storybook/react';
import Plant from './Plant';

storiesOf('Atoms/Plant', module).add('Normal', () => <Plant />);
