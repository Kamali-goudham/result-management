import React, { Component } from 'react'
export default class View extends Component {
  
  render() {
    return (
      <section>
        <div>
            <br></br><br></br><br></br><br></br>
      <footer class="footer section">
      <div class="footer__container container grid">
          <div class="footer__content">
          </div>

          <div class="footer__content">
              <h3 class="footer__title">Our Address</h3>

              <ul class="footer__data">
                  <li class="footer__information">73-Major Saravanan Nagar</li>
                  <li class="footer__information">Karuvadikuppam</li>
                  <li class="footer__information">Puducherry</li>
              </ul>
          </div>

          <div class="footer__content">
              <h3 class="footer__title">Contact Us</h3>

              <ul class="footer__data">
                  <li class="footer__information">+999 888 777</li>
                  
                  <div class="footer__social">
                      <a href="https://www.facebook.com/" class="footer__social-link">
                          <i class="ri-facebook-fill"></i>
                      </a>
                      <a href="https://www.instagram.com/" class="footer__social-link">
                          <i class="ri-instagram-line"></i>
                      </a>
                      <a href="https://twitter.com/" class="footer__social-link">
                          <i class="ri-twitter-fill"></i>
                      </a>
                  </div>
              </ul>
          </div>

          <div class="footer__content">
              <h3 class="footer__title">
                  We accept all credit cards
              </h3>

              <div class="footer__cards">
                  <img src="./public/card1.png" alt="" class="footer__card"></img>
                  <img src="./card2.png" alt="" class="footer__card"></img>
                  <img src="./card3.png" alt="" class="footer__card"></img>
                  <img src="./card4.png" alt="" class="footer__card"></img>
              </div>
          </div>
      </div>

      <p class="footer__copy">&#169; All rigths reserved 2023</p>
  </footer>
  </div>
  </section>
  
    )
  }
}