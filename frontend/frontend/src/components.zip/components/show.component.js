import React, {useEffect, useState} from 'react'

import { FaPen, FaTrash, FaMinusCircle, FaPlus } from "react-icons/fa";

//useState :to add state to a functional component
// It allows us to track state in a function component


function Show() {
  const [plantData, setPlantData] = useState([{}])
  const [popup, setPopup] = useState(false)
  const [isCreate, setisCreate] = useState(true)
  const [plantid, setID] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [descs, setDescs] = useState("");
  const [dateadded, setDateadded] = useState("");
   const [category, setCategory] = useState("");
     const [url, setUrl] = useState("");
  
  

//You can easily submit form asynchronously with handleSubmit
//The handleChange function is pretty simple, it used React's setState method to update the value.
//handleSubmit gets the current value of state. value and adds it to the array of webhooks

  const handleSubmit = (event) => {
    event.preventDefault();
    let data = {};
    if(isCreate){
      data = {
        name, price, descs,dateadded,category,url
      }
    }
    else {
      data = {
        plantid, name, price, descs,dateadded,category,url
      }
    }
    createPlants(data, isCreate);
  }
 
//The useEffect Hook allows you to perform side effects in your components : data fetch and update Dom
useEffect(() => {
  getPlants();
}, [])

//GetPlants API call
const getPlants = () => {
  fetch('http://localhost:8081/plant').then(
    response => response.json()
  )
  .then(data => {
    console.log(data)
    setPlantData(data)
  }, (e) =>{
    console.log(e);
  })
}

//React-async provides a declarative API to perform any REST API calls using a single React component.
//It takes care of handling errors, promise resolution, and retrying promises, and deals with local asynchronous state.

// await fetch(URL):  the asynchronous function is paused until the request completes.
//When the request completes, response is assigned with the response object of the request

const createPlants = async(data, insert) => {
  try {
    let URL = 'http://localhost:8081/plants'
    if(insert) URL = 'http://localhost:8081/plants'
    const response = await fetch(URL, {
      method: "POST", // or 'PUT'
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();
    console.log("Success:", result);
    EditPopup();
    getPlants();
  } catch (error) {
    console.error("Error:", error);
  }
}


const deletePlants = async(data) => {
  try {
    let URL = 'http://localhost:8081/plant'
   
    const response = await fetch(URL, {
      method: "DELETE", // or 'PUT'
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();
    console.log("Success:", result);
  
    getPlants();
  } catch (error) {
    console.error("Error:", error);
  }
}

const EditPopup = () => {
 
  setPopup(!popup)
}

const SetCreateValues = () => {
  setID("");
  setisCreate(true);
  setName("");
  setPrice("");
  setDescs("");
  setDateadded("");
  setCategory("");
  setUrl("");
  EditPopup();
}
const SetEditValues = (plant) => {
  setID(plant.plantid);
  setisCreate(false);
  setName(plant.name);
  setPrice(plant.price);
  setDescs(plant.descs);
  setDateadded(plant.dateadded);
  setCategory(plant.category);
  setUrl(plant.url);

  EditPopup();
}

  return (
    <div>
      <div style={{
               
                margin: 10,
                backgroundColor: '#E7B10A',
                padding: 10,
                width: 100
              }}  onClick={SetCreateValues}> <FaPlus />  Add Plant</div>

   

      {(typeof plantData === 'undefined') ? (
        <p>Loading...</p>
            ) : (
              <div style={{
                display : 'flex',
                flexDirection: 'column',
               
               
                padding: "10px",
                fontFamily: "Arial" }}>
                  <div style={{
                display : 'flex',
                padding: 10,
                backgroundColor: '#BFDB38',
                flexDirection: 'row',
                margin: 10,
             
                justifyContent: 'space-between'
              }}>
                  <div>Id</div>
                  <div>Name</div>
                  <div>Price</div>
                  <div>Description</div>
                  <div>Date Added</div>
                   <div>Category</div>
                   <div>Image</div>
                  <div></div>
                  <div></div>
                  </div>
                  { plantData.map((plant, i) => {
                 return(
                  <div style={{
                display : 'flex',
                margin: 10,
                backgroundColor: '#E4C988',
                padding: 10,
                flexDirection: 'row',
                justifyContent: 'space-between'
              }}>
                <div>{plant.plantid}</div>
                <br></br>
                  <div>{plant.name}</div>
                  <br></br>
                  <div>{plant.price}</div>
                  <div>{plant.descs}</div>
                   <div>{plant.dateadded}</div>
                    <div>{plant.category}</div>
                    <br></br>
                    <br></br>
                    <br></br><br></br>
                    <div><img src={plant.url} width="125px"
            height="100px"/></div>
                  <div onClick={() => SetEditValues(plant)}><FaPen/></div>
                  <div onClick={() => deletePlants(plant)}><FaTrash/></div>
                 
                  </div> )
                  })}
                 
              </div>
             
            )  }
      {popup && (
     <div style={{
          position: "absolute",
         
          backgroundColor: "#84D2C5",
          height: "100%",
          width: "100%",
          top: 0
         
        }}>

          <div style={{backgroundColor: "#e0e0e0",
          width: "50%",
          height: "50%",
          margin: "auto",
          top: 20}}>
           
<FaMinusCircle style={{padding: 10}} onClick={EditPopup} />
<form onSubmit={handleSubmit}>
  <br></br><br></br><br></br>
  <div style={{flexDirection : "row", padding: 10}}>
  <label>Enter Plant name:
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      
  </div>
  <div style={{flexDirection : "row",  padding: 10}}>
      <label>Enter Plant Price:
        <input
          type="text"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
      </label>
      </div>
      <div style={{flexDirection : "row",  padding: 10}}>
      <label>Enter Plant Description:
        <input
          type="text"
          value={descs}
          onChange={(e) => setDescs(e.target.value)}
        />
      </label>
      </div>
      <div style={{flexDirection : "row",  padding: 10}}>
      <label>Enter Date it was added:
        <input
          type="date"
          value={dateadded}
          onChange={(e) => setDateadded(e.target.value)}
        />
      </label>
      </div>
       <div style={{flexDirection : "row",  padding: 10}}>
      <label>Enter Category:
        <input
          type="text"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
      </label>
      </div>
      <div style={{flexDirection : "row",  padding: 10}}>
      <label>Enter image url:
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </label>
      </div>
      <div style={{flexDirection : "row",  padding: 10}}><input type="submit" /></div>
     
    </form>
          </div>
        </div>
        )}
    </div>
  );
}



export default Show;