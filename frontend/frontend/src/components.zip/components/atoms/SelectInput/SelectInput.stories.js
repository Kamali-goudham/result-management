import React from 'react';
import { storiesOf } from '@storybook/react';
import SelectInput from './SelectInput';

storiesOf('Atoms/SelectInput', module).add('Normal', () => <SelectInput />);
