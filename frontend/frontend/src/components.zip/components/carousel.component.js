import React, { Component } from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
export default class Home extends Component{
render(){
        return(
        <section className='home'>
        <div>
        <Carousel>
                     <div className='head-text'>
                      <div className='head-text'>
                      <img src="./pl4.jpg" />
                          <p className="legend"></p>
                      </div>
                      
                      <div className='text-on-image'>
                        <br></br>
                        
                          <h1><p>Plants are Solar powered air purifiers whose filter never needs replacing.</p></h1>
                          {/* <button type="submit" className="btn btn-primary" >
                 View Product 
                </button>
                */}
                        
                      </div>
                      </div>
                      <div className='head-text'>
                      <div className='head-text'>
                      <img src="./joy.jpeg" />
                          <p className="legend"></p>
                      </div>
                      <div className='text-on-image1'>
                        <br></br>
                        <br></br>
                        <br></br>
                        <br></br>
                        <h1><small><p>One day is not enough to green our earth.Planting caring and love is also expecting our earth from us.
                           Do it, It will heal not  only the land but also your body and mind .</p></small></h1>
                        
                      </div>
                      </div>
                      <div className='head-text'>
                      <div className='head-text'>
                      <img src="./pl6.jpg" />
                          <p className="legend"></p>
                      </div>
                      <div className='text-on-image'>
                        <h1></h1>
                        
                      </div>
                      </div>
                      <div className='head-text'>
                      <div className='head-text'>
                      <img src="./green-sprouts.jpg" />
                          <p className="legend"></p>
                      </div>
                      <div className='text-on-image'>
                        <h1></h1>
                        
                      </div>
                      </div>
                      <div className='head-text'>
                      <div className='head-text'>
                      <img src="./pl2.jpg" />
                          <p className="legend"></p>
                      </div>
                      <div className='text-on-image'>
                        <h1></h1>
                        
                      </div>
                      </div>
                      
                  </Carousel>
                    
        </div> 
        </section>
        // <div class="carousel-wrapper">
        //     <Carousel infiniteLoop useKeyboardArrows autoPlay>
        //         <div>
        //             <img src="./sunplants.jpg" />
        //         </div>
        //         <div>
        //             <img src="../img-02.jpg" />
        //         </div>
        //         <div>
        //             <img src="../img-03.jpg" />
        //         </div>
        //     </Carousel>
        // </div>
        
    )
}

}
